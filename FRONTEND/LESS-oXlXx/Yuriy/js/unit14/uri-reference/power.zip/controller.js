renderMain(message, generatedPower, threshold, electricityConsumption)
